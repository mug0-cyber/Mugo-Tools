print("""
███╗   ███╗    ██╗   ██╗     ██████╗      ██████╗ 
████╗ ████║    ██║   ██║    ██╔════╝     ██╔═══██╗
██╔████╔██║    ██║   ██║    ██║  ███╗    ██║   ██║
██║╚██╔╝██║    ██║   ██║    ██║   ██║    ██║   ██║
██║ ╚═╝ ██║    ╚██████╔╝    ╚██████╔╝    ╚██████╔╝
╚═╝     ╚═╝     ╚═════╝      ╚═════╝      ╚═════╝ 
                                                  
Güncelleme Yapmak İçin 'cmd' Üzerine 'mugo_updater' Yazmanız Yeterli!

         Kullanım Çok Basit!
         Öncelikle Bilgisayarınıza Python Yüklü Olması Gerekir!
         Bazı Tool-Script ler "curl" Yüklü Olmasını İster! eğer curl Yüklü Değil İse O Tool-Script Çalışmayacaktır!
         Öncelikle 'Bu Bilgisayar' a Sağ Tıklayıp 'Özellikler' e Gidiyoruz!
         Daha Sonra 'Gelişmiş sistem ayarları' Bölümüne Gidiyoruz 
         Ve Üst Bar'dan 'Gelişmiş' Kısmına Geçiyoruz! 'Ortam Değişkenleri' Tuşuna Basarak Gelen Kısımda Üstte 'Path' e Basıp 'Düzenle' Diyoruz!
         Ve Çıkan Yerde 'Yeni' Tuşuna Basıp 'C:\HACK\TOOLS' Yolunu [' (Tek Tırnak İşareti) Olmadan] Yazıyoruz Ve 'Tamam' Diyoruz!
         Daha Sonra Alt Kısımda 'Path' Bulup Basıyor Ve 'Düzenle' Diyoruz.
         Sonra Tekrardan 'Yeni' Basıp Aynı Yolu Yapıştırıyor Ve 'Tamam' Diyoruz!
         Bilgisayar'ınızı Yeniden Başlatmanız Sonucunda Artık 'cmd' kullanılarak Komutlar Yazıla Bilir!
         İlk Olarak 'cmd' ye 'setup' Komutu Yazılarak Çalıştırıla Bilir Script ler Listelenir!
         -----------------------------------------------------------------------------------------------------------------------------------------
        "setup" Komutu Çalıştırılarak Aynı Zamanda Yeni Sürüm Geldiğinde Anında Yeni Sürümden Haberdar Olabilirsiniz!
         -----------------------------------------------------------------------------------------------------------------------------------------
         Bilgisayar'ınızı Yeniden Başlatmanız Sonucunda Artık 'cmd' kullanılarak Komutlar Yazıla Bilir!
         İlk Olarak 'cmd' ye 'setup' Komutu Yazılarak Çalıştırıla Bilir Script ler Listelenir!
         -----------------------------------------------------------------------------------------------------------------------------------------
         Created By Mugo""")

input("'Enter' Basarak Çıka Bilirsiniz!")