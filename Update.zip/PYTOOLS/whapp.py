import os

groupnm = str(input("Aranacak Grub İsmini Girin : "))

site = "start https://www.google.com/search?q=site%3Ahttps%3A%2F%2Fchat.whatsapp.com+inurl%3A%2Finvite%2F+intext%3A{}".format(str(groupnm))
os.system(site)
exit()