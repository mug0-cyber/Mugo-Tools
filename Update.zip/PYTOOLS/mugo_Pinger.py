from os import system
from time import sleep

def cls():
    system("cls")

def isleme():
    system("color 02")
    cls()
    print("Bilgiler İşleniyor.")
    sleep(0.5)
    cls()
    print("Bilgiler İşleniyor..")
    sleep(0.5)
    cls()
    print("Bilgiler İşleniyor...")
    sleep(0.5)
    cls()
    print("Bilgiler İşleniyor ..")
    sleep(0.5)
    cls()
    print("Bilgiler İşleniyor  .")
    sleep(0.5)
    system("color 07")
    cls()
print("""***********************\nBilgilendirme\n
İstatistikleri görmek ve devam etmek için Control-Break Basın;                  
Durdurmak için Control-C yazın\n***********************\n""")

mchange = int(input("1 : Domain\n0 : IP\nSalırı Yapılacak Hedef [1/0] : "))
if (mchange == 1):
    rhost = str(input("Ping Atılacak Hedef Domain : "))
    resolvechange = str(input("Ping Atılacak Domain IP Çevirilsin mi? [Y/N] : "))
    if resolvechange == "Y":
        rhost = " -a " + rhost
    else:
        rhost = rhost
elif (mchange == 0):
    rhost = str(input("Ping Atılacak Hedef IP : "))
    
else:
    print("Yanlış Değer Girildi!")
    exit()
psize = str(input("Atılacak Ping Boyutu (Oto : 32, Max : 65500): "))
pcount = str(input("Gönderilecek Ping İsteklerinin Sayısı : "))

isleme()
if psize == "":
    commands = ("ping -n {} {}").format(pcount, rhost)
else:
    commands = ("ping -l {} -n {} {}").format(psize, pcount, rhost)
cls()
print("Ping Gönderim İşlemi Başlatıldı. Lütfen Saldırı Amaçlı Kullanmayın!")

print("""
                      █
                     ███
                    ███ █  █            ███
 ███              ██████ ███         ███
    ███          ███   ████       ███   ███
 ████  ███       █     █       ███   ███
     ███  ███          █   ████   ███  █
     █  ███  ████      ████    ███   ██
      ██   ███   ███████   ████  ████
        ████  ██████  █ ███  ████
            ████ ██████    ██
                ██  ████ ██
                  ██  ███ █
                    ██ ███
                      █ █ █
                       ███
                        ████
                          ███
                            ██
                              █""")

system(commands)