from urllib import request
from os import chdir
import zipfile
import urllib3
import random
from time import sleep

chdir("C:\\HACK")

url = urllib3.PoolManager()
connection1 = url.request('GET', "https://raw.githubusercontent.com/mug0-cyber/Mugo-Tools/master/Changelog.txt", headers={
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36",
            'Cache-Control': "no_cache",
            'Accept-Charset': "ISO-8859-1,utf-8;q=0.7,*;q=0.7",
            'Keep-Alive': str(random.randint(110,120)),
            'Connection': "keep_alive",
            'Host': "raw.githubusercontent.com",
            'Content-Type': 'application/x-www-form-urlencoded'
            })
con = connection1.data.decode('utf-8')

if con != "0.0.3":
    print("Sürümünüz Güncel Değildir! Yeni Sürüm :", con)
    input("ENTER'a Basarak Güncellemeyi Yapabilirsiniz!")
else:
    print("Sürümünüz Günceldir Tool lar Rahatlıkla Çalıştırılabilir! Mevcut Sürüm :", con)
    sleep(5)
    exit()

print("""

   *                          )   
 (  `             (        ( /(   
 )\))(       (    )\ )     )\())  
((_)()\      )\  (()/(    ((_)\   
(_()((_)  _ ((_)  /(_))_    ((_)  
|  \/  | | | | | (_)) __|  / _ \  
| |\/| | | |_| |   | (_ | | (_) | 
|_|  |_|  \___/     \___|  \___/  
                                  
""")

con = request.urlopen("https://github.com/mug0-cyber/Mugo-Tools/raw/master/Update.zip?raw=true")
dosya = open("Update.zip", "wb")
dosya.write(con.read())
dosya.close()
con.close()

with zipfile.ZipFile("Update.zip", 'r') as zip_ref:
    zip_ref.extractall()

input("ENTER Basarak Uygulamadan Çıkış Yapa Bilirsiniz \n")