import urllib3
from os import chdir
from os import startfile

headers = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36")

url = urllib3.PoolManager()

connection = url.request('GET', "thispersondoesnotexist.com/image", headers={
            'User-Agent': headers,
            'Cache-Control': "no_cache",
            'Accept-Charset': "isochange",
            'Connection': "keep_alive",
            'Host': "thispersondoesnotexist.com",
            'Content-Type': 'application/x-www-form-urlencoded'
            })

dosya = open("Fake Person Image By M U G O.png", "wb")
dosya.write(connection.data)
dosya.close()
connection.close()
startfile("Fake Person Image By M U G O.png")