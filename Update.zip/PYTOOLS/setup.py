from os import system
from os import chdir
from os import listdir

print("""
 ███▄ ▄███▓    █    ██      ▄████     ▒█████  
▓██▒▀█▀ ██▒    ██  ▓██▒    ██▒ ▀█▒   ▒██▒  ██▒
▓██    ▓██░   ▓██  ▒██░   ▒██░▄▄▄░   ▒██░  ██▒
▒██    ▒██    ▓▓█  ░██░   ░▓█  ██▓   ▒██   ██░
▒██▒   ░██▒   ▒▒█████▓    ░▒▓███▀▒   ░ ████▓▒░
░ ▒░   ░  ░   ░▒▓▒ ▒ ▒     ░▒   ▒    ░ ▒░▒░▒░ 
░  ░      ░   ░░▒░ ░ ░      ░   ░      ░ ▒ ▒░ 
░      ░       ░░░ ░ ░    ░ ░   ░    ░ ░ ░ ▒  
       ░         ░              ░        ░ ░  
                                              
""")
print("---------------------------------------------------------------------------------")
print("|Bu Hack Tools Mugo Tarafından Windows Kullanıcılarına Özel Olarak Kodlanmıştır!|")
print("---------------------------------------------------------------------------------")
print("Mevcut Uygulama Sürümü : 0.0.1")
print("Lütfen Bu Uygulamaları Kullanırken Kötü Amaçlarla (Amaç Dışı) Kullanmayınız Sayın ")
system("echo %username%")
print("Kullanım İçin howtouse Komutunu 'cmd' Üzerine Yazınız!")
print("---------------------------------------------------------------------------------")
print("Şu Anda Yüklü Olan Script/Tool lar : ")
print("------------------")
dirlist = listdir('C:\\HACK\\TOOLS')
for g in dirlist:
    g = g.replace(".bat", "\n------------------")
    print(g)
system("start")
input("Çıkmak İçin 'Enter' Tuşuna Basın!")