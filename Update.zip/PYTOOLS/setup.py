from os import system
from os import chdir
from os import listdir
import urllib3
import random

url = urllib3.PoolManager()
connection1 = url.request('GET', "https://raw.githubusercontent.com/mug0-cyber/Mugo-Tools/master/Changelog.txt", headers={
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36",
            'Cache-Control': "no_cache",
            'Accept-Charset': "ISO-8859-1,utf-8;q=0.7,*;q=0.7",
            'Keep-Alive': str(random.randint(110,120)),
            'Connection': "keep_alive",
            'Host': "raw.githubusercontent.com",
            'Content-Type': 'application/x-www-form-urlencoded'
            })
con = connection1.data.decode('utf-8')
print("""
 ███▄ ▄███▓    █    ██      ▄████     ▒█████  
▓██▒▀█▀ ██▒    ██  ▓██▒    ██▒ ▀█▒   ▒██▒  ██▒
▓██    ▓██░   ▓██  ▒██░   ▒██░▄▄▄░   ▒██░  ██▒
▒██    ▒██    ▓▓█  ░██░   ░▓█  ██▓   ▒██   ██░
▒██▒   ░██▒   ▒▒█████▓    ░▒▓███▀▒   ░ ████▓▒░
░ ▒░   ░  ░   ░▒▓▒ ▒ ▒     ░▒   ▒    ░ ▒░▒░▒░ 
░  ░      ░   ░░▒░ ░ ░      ░   ░      ░ ▒ ▒░ 
░      ░       ░░░ ░ ░    ░ ░   ░    ░ ░ ░ ▒  
       ░         ░              ░        ░ ░  
                                              
""")
print("---------------------------------------------------------------------------------")
print("|Bu Hack Tools Mugo Tarafından Windows Kullanıcılarına Özel Olarak Kodlanmıştır!|")
print("---------------------------------------------------------------------------------")
if con != "0.0.3":
    print("Sürümünüz Güncel Değildir! Güncellemeniz Önerilir. Yeni Sürüm :", con)
else:
    print("Sürümünüz Günceldir Tool lar Rahatlıkla Çalıştırılabilir! Mevcut Sürüm :", con)

print("Lütfen Bu Uygulamaları Kullanırken Kötü Amaçlarla (Amaç Dışı) Kullanmayınız Sayın, ")
system("echo %username%")
print("Kullanım İçin howtouse Komutunu 'cmd' Üzerine Yazınız!")
print("---------------------------------------------------------------------------------")
print("Güncelleme Yapmak İçin 'cmd' Üzerine 'mugo_updater' Yazmanız Yeterli!")
print("Şu Anda Yüklü Olan Script/Tool lar : ")
print("------------------")
dirlist = listdir('C:\\HACK\\TOOLS')
for g in dirlist:
    g = g.replace(".bat", "\n------------------")
    print(g)
system("start")
input("Çıkmak İçin 'Enter' Tuşuna Basın!")